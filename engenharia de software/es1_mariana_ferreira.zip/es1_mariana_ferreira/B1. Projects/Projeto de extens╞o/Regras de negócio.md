1. Progressão e aumento de complexidade
	1.1: Conforme o jogador progride, a complexidade do jogo deve aumentar. Cada nível subsequente deve introduzir novos desafios, aumentar a dificuldade dos desafios existentes.
2. Exibição de pontuação
	2.1: A pontuação atual do jogador deve ser visível na interface do usuário durante o jogo, permitindo que o jogador acompanhe seu progresso em tempo real. 
3. Progressão após conclusão de cada nível
	3.1:  O jogo deve progredir automaticamente após a conclusão de cada nível. O progresso deve ser salvo automaticamente.
4.  Feedback ao jogador
	4.1:  Feedback visual e sonoro quando o jogador acerta ou erra a sequência proposta a ser memorizada. 
	4.2: Dicas ou sugestões durante o jogo.

