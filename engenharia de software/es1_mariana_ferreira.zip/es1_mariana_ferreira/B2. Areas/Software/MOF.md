Meta - Object Facility

- [[UML]] e [[BPMN]] se baseiam nessa meta linguagem
- omg.org/mof/index.htm
- omg.org/spec/MOF/2.4.2
