"Um stakeholder é qualquer indivíduo que tem interesse no sucesso do projeto."
														(Pressman, 2021)

A expressão "Have a stake in" significa ter uma participação, interesse ou envolvimento em algo ou alguém. Isso pode se referir a uma parte em um negócio, uma preocupação com o futuro de alguém ou qualquer situação em que se tenha algo a ganhar ou perder. A origem dessa expressão vem do uso da palavra "stake" no sentido de "algo a ganhar ou perder", como em apostas. A expressão começou a ser usada no final dos anos 1700.

													05 de junho de 2024