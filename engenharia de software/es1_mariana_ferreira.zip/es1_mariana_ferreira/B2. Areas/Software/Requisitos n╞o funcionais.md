- Descrevem as qualidades e atributos do sistema, como ele deve se comportar e as restrições sobre seu design e implementação.
- Focam em como o sistema deve funcionar em termos de desempenho, segurança, usabilidade, etc.
- Incluem restrições de design, implementação e tecnologia.
- Muitas vezes são mensuráveis através de métricas específicas.



				                                      12 de junho de 2024