- Descrevem as funcionalidades que o sistema deve possuir para atender às necessidades dos usuários e aos objetivos do negócio.
- Devem ser categorizados de acordo com o contexto
- Detalham as tarefas, comportamentos e funções específicas que o sistema deve executar.
- Explicam como os usuários interagem com o sistema.
- Descrevem o fluxo de processos dentro do sistema.






			                                       12 de junho de 2024