linhas gerais do SQUAD: [https://blog.crisp.se/wp-content/uploads/2012/11/SpotifyScaling.pdf](https://blog.crisp.se/wp-content/uploads/2012/11/SpotifyScaling.pdf "https://blog.crisp.se/wp-content/uploads/2012/11/spotifyscaling.pdf")

- derivado da linha de métodos ágeis
- é simples e aborda a agilidade
- foco na organização em torno do trabalho e não em tarefas especificas do desenvolvimento
- como as empresas podem estruturar a organização
- equipes autônomas multifuncionais
- se concentram em uma área de recurso
- compartilham uma missão única que orienta o trabalho (tem uma coesão dentro do domínio da empresa)
- os papeis mais importantes nesse contexto são: agile coach e product owner (similares aos papeis dos métodos ágeis)
- determinam qual metodologia ou estrutura ágil será adotada
- tribes:
	- são squads coordenados entre si
	- ajudam a criar alinhamento entre squads
- chapters:
	- grupo de especialistas que ajuda a manter o alinhamento dos padrões de engenharia de cada disciplina
- ![[Pasted image 20240605193935.png]]
- guild:
	- comunidade de interesse
	- o ingresso é voluntário
	- podem convergir entre as tribes
	- não tem um líder formal
- ![[Pasted image 20240605194234.png]]
- trio:
	- um papel gerencial pra ter uma combinação de líder de tribe, de produto e de design
	- alinhamento das três perspectiva
- aliance:
	- de acordo com a escalabilidade das empresas, ás vezes, várias tribes precisam trabalhar em conjunto para atingir uma meta.

- pontos positivos do SQUAD:
	- menos formalidade
	- é autogerenciável
	- alta autonomia



														05 de junho de 2024