- Diretrizes ou políticas que definem ou restringem aspectos do negócio e que devem ser obedecidas para garantir a conformidade e a operação adequada do sistema.
- Focam nas necessidades e práticas do negócio, não em aspectos técnicos.
- Derivam de políticas empresariais, regulamentações legais ou decisões estratégicas.
- Determinam como as decisões são tomadas e estabelecem restrições operacionais.


								                         12 de junho de 2024