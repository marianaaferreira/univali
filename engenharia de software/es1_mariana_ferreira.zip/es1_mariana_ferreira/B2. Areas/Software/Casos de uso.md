- Um caso de uso é uma descrição textual de como um usuário externo (ator) interage com o sistema para realizar uma tarefa ou atingir um objetivo específico.
- O termo "usuário" pode significar diferentes entidades
- Interação: Refere-se a qualquer ação ou série de ações que tem significado para o usuário final.
- Os atores não fazem parte do sistema
- O nome que identifica o ator deve ser o papel que ele desempenha na utilização do sistema
- O ator é alguém que é usuário do sistema e não o sistema que está sendo modelado




									19 de junho de 2024