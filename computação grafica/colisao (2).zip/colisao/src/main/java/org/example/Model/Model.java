package org.example.Model;

public abstract class Model {
	abstract public void load();
	abstract public void draw();
}
